========
Easy API
========

Easy API simplifies access to standardized REST API's.  It allows you to 
access and use the API as a simple python list of objects. 

Contributors
------------
Adrian Czebiniak

